Vampires Strike Back 1.8.1 - Español (España)

Versión objetivo:
- Minecraft 1.20.1
- Vampires Strike Back 1.8.1

Este parche añade traducciones es_es para el contenido personalizado del modpack
(Origins, historia, quests, reputación, KubeJS, renombres, menús y textos asociados).
También añade nombres personalizados en español para varios objetos de Artifacts.

Instalación manual:
1. Instala Vampires Strike Back 1.8.1 en CurseForge.
2. Copia este ZIP a la carpeta "resourcepacks" del perfil.
3. En Minecraft: Opciones > Paquetes de recursos.
4. Activa "Vampires Strike Back - Español" y colócalo ARRIBA de los demás.
5. Idioma: Español (España).

No modifica mods .jar ni la lógica del modpack.
